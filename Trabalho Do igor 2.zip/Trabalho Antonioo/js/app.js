const container = document.querySelector(".container")
const coffees = [
  { name: "Saturno Burger 30$", image: "images/saturno1.png" },
  { name: "Marte Burger 30$", image: "images/marte1.png" },
  { name: "Galaxy Burger 30$", image: "images/galaxy1.png" },
  { name: "Jupiter Burger 30$", image: "images/jupiter1.png" },
  { name: "Venus Burger 30$", image: "images/venus1.png" },
  { name: "Terra Burger 30$", image: "images/terra1.png" },
  
]

const showhamburger= () => {
    let output = ""
    coffees.forEach(
      ({ name, image }) =>
        (output += `
                <div class="card">
                  <img class="card--avatar" src=${image} />
                  <h1 class="card--title">${name}</h1>
                  <a class="card--link" href="carrinho.html">Carrinho +</a>
                </div>
                `)
    )
    container.innerHTML = output
  }
  
  document.addEventListener("DOMContentLoaded", showhamburger)


  if ("serviceWorker" in navigator) {
    window.addEventListener("load", function() {
      navigator.serviceWorker
        .register("/serviceWorker.js")
        .then(res => console.log("service worker registered"))
        .catch(err => console.log("service worker not registered", err))
    })
  }